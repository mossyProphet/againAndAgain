<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ThisIsMyTileSet" tilewidth="40" tileheight="24" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="3">
  <image width="40" height="24" source="C:/../../../../Program Files (x86)/Steam/steamapps/common/Starbound/mods/againandagain/objects/tm_crafting/crafter/crafter.png"/>
 </tile>
</tileset>
