require "/scripts/util.lua"

function init()
  
end

function update(dt)
  object.setInteractive(true)
end
