function init()
	status.setResource("setBonusChest", 2)
end

function update(dt)
  
end

function uninit()
   status.setResource("setBonusChest", 0)
end
