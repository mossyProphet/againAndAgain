function init()
	status.setResource("setBonusLegs", 2)
end

function update(dt)
  
end

function uninit()
   status.setResource("setBonusLegs", 0)
end
