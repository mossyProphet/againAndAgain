function init()
  --Power
  self.powerModifier = config.getParameter("powerModifier", 0)
  effect.addStatModifierGroup({{stat = "powerMultiplier", effectiveMultiplier = self.powerModifier}})
  --script.setUpdateDelta(5)
  local enableParticles = config.getParameter("particles", true)
  animator.setParticleEmitterOffsetRegion("embers", mcontroller.boundBox())
  animator.setParticleEmitterActive("embers", enableParticles)
end


function update(dt)
  local enableParticles = config.getParameter("particles", true)
  animator.setParticleEmitterOffsetRegion("blood", mcontroller.boundBox())
  animator.setParticleEmitterActive("blood", enableParticles)
end

function uninit()

end
