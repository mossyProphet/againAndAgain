function init()
	status.setResource("setBonusChest", 3)
end

function update(dt)
  
end

function uninit()
   status.setResource("setBonusChest", 0)
end
