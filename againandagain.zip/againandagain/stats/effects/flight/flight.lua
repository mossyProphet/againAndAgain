function init()
  self.glideSpeed = config.getParameter("glideSpeed")
  
end

function update(args)
  effect.addStatModifierGroup({{stat = "fallDamageMultiplier", effectiveMultiplier = 0}})
  if not mcontroller.onGround() then
     mcontroller.controlModifiers({speedModifier = 4*self.glideSpeed})
     if mcontroller.falling() then
     mcontroller.setYVelocity(mcontroller.yVelocity()/self.glideSpeed)
     end
   end
end

function uninit()
  effect.addStatModifierGroup({{stat = "fallDamageMultiplier", effectiveMultiplier = 1}})
end

