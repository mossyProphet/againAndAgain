function init()
  --podsCur = status.resource("minionSlotsCount")
  
  minionBoost = config.getParameter("minionBonus", 1)
  --minionBonus = (status.resource("minionSlotsCount") + 4)/4
  isApplied = false
  --effect.addStatModifierGroup({{stat = "minionStatsBonus", effectiveMultiplier = minionBonus}})
end

function update(dt)
	if not isApplied then
		status.modifyResource("minionSlotsCount", minionBoost)
		if entity.entityType() == "monster" then
			--effect.addStatModifierGroup({{stat = "powerMultiplier", amount = 1}})
			effect.addStatModifierGroup({{stat = "maxHealth", baseMultiplier = 1.05*minionBonus}})
			effect.addStatModifierGroup({{stat = "healthRegen", amount = 10*minionBonus}})
		end
		isApplied = true
	end
end

function uninit()
  status.consumeResource("minionSlotsCount", minionBoost)
  isApplied = false
end