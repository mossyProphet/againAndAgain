function init()
  --podsCur = status.resource("minionSlotsCount")
  
  minionBoost = config.getParameter("minionBonus", 1)
  minionBonus = (status.resource("minionSlotsCount") + 4)/4
  status.modifyResource("minionSlotsCount", minionBoost)
  effect.addStatModifierGroup({{stat = "minionStatsBonus", effectiveMultiplier = minionBonus}})
end

function update(dt)
end

function uninit()
  status.consumeResource("minionSlotsCount", minionBoost)
end