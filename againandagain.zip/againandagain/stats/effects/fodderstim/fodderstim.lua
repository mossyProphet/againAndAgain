
function init()
  podsCur = status.resource("minionSlotsCount")
  status.modifyResource("minionSlotsCount", podsCur)
end

function update(dt)
end

function uninit()
  status.consumeResource("minionSlotsCount", podsCur)
end