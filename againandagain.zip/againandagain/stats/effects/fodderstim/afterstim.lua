
function init()
  --podsCur = status.resource("minionSlotsCount")
  --status.overConsumeResource("minionSlotsCount", podsCur)
  status.setResource("minionSlotsCount", 1)
end

function update(dt)
  
end

function uninit()
 
end