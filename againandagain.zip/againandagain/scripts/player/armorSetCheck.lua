require "/scripts/status.lua"
require "/scripts/util.lua"
require "/scripts/messageutil.lua"


function init()
	message.setHandler("isSetAdequate", function(_, _, player)
      isSetAdequate()
    end)
end

function isSetAdequate()
	outputta = false
	
	storage.player = player.id()
	sb.logInfo("player = : %s",storage.player)

	legs = (player.equippedItem("legs") == "predatorypants")
	chest = (player.equippedItem("chest") == "predatorychest")
	head = (player.equippedItem("legs") == "predatoryhead")

	outputta = legs and chest and head
	sb.logInfo("outputta = : %s",outputta)
	return outputta
end
