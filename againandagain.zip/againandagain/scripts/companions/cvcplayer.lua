require "/scripts/companions/petspawner.lua"
require "/scripts/companions/recruitspawner.lua"
require "/scripts/achievements.lua"


function getPetPersistentEffects()
  --local effects = filterPersistentEffects(status.getPersistentEffects("armor"))
  local effects = status.getPersistentEffects("armor") 
  --util.appendLists(effects, status.getPersistentEffects("minions"))
  --sb.logInfo("minions get %s",  status.getPersistentEffects("minions"))
  --util.appendLists(effects, )
  --sb.logInfo("%s", effects)
  if onOwnShip() then
    --sb.logInfo("ship = %s", recruitSpawner:getShipPersistentEffects())
    util.appendLists(effects, recruitSpawner:getShipPersistentEffects())
    
  end
  --sb.logInfo("%s",  status.getPersistentEffects("armor"))
  return effects
end

function init()
  --self.activePodLimit = config.getParameter("activePodLimit") 
  --status.setResource("minionSlotsCount", 0)
  -- Sets up handlers for messages common to all pet spawner types:
  petSpawner:init()
  -- Sets up handlers for messages common to all recruit spawner types:
  recruitSpawner:init()
  petCount = 0
  --storage.pods = {}
  --status.setResource("minionSlotsCount", 0)
  -- Messages specific to player-spawned pets:
  message.setHandler("pets.podPets", localHandler(podPets))
  message.setHandler("pets.setPodPets", localHandler(setPodPets))
  message.setHandler("pets.isPodActive", localHandler(isPodActive))
  message.setHandler("pets.activatePod", localHandler(activatePod))
  message.setHandler("pets.deactivatePod", localHandler(deactivatePod))
  message.setHandler("pets.togglePod", localHandler(togglePod))
  message.setHandler("pets.spawnFromPod", localHandler(spawnFromPod))
  message.setHandler("pets.podsLimit", localHandler(podsLimit))

  --Messages specific to player-spawned recruits:
  message.setHandler("recruits.offerRecruit", simpleHandler(offerRecruit))
  message.setHandler("recruits.offerMercenary", simpleHandler(offerMercenary))
  message.setHandler("recruits.requestFollow", simpleHandler(requestFollow))
  message.setHandler("recruits.requestUnfollow", simpleHandler(requestUnfollow))
  message.setHandler("recruits.offerUniformUpdate", simpleHandler(offerUniformUpdate))
  message.setHandler("recruits.triggerFieldBenefits", simpleHandler(triggerFieldBenefits))
  message.setHandler("recruits.triggerCombatBenefits", simpleHandler(triggerCombatBenefits))

  petSpawner.ownerUuid = entity.uniqueId()
  recruitSpawner.ownerUuid = entity.uniqueId()
  recruitSpawner.activeCrewLimit = config.getParameter("activeCrewLimit")
  recruitSpawner.crewLimit = function() return player.shipUpgrades().crewSize end

  for uuid, podStore in pairs(storage.pods or {}) do
    petSpawner.pods[uuid] = Pod.load(podStore)
  end

  local followers = playerCompanions.getCompanions("followers")
  for _,follower in pairs(followers) do
    follower.uniqueId = nil
  end
  recruitSpawner:load({
      followers = followers,
      shipCrew = playerCompanions.getCompanions("shipCrew")
    }, storage.recruits or {})

  storage.activePods = storage.activePods or {}
  self.spawnedCompanions = false

  
  --if minionInit then else minionInit = 1
  --status.stat("minionStatsBonus")
  
end

-- Releases the pets that are currently active. Triggered by player init,
-- but only runs after the player's map sector is loaded.
function spawnCompanions()
  if world.pointTileCollision(entity.position(), {"Null"}) then
    -- The player's sector is not loaded yet. We need it to be loaded in
    -- order to be able to spawn pets at positions that won't intersect
    -- world geometry.
    return false
  end

  

  for uuid,_ in pairs(storage.activePods) do
    petSpawner.pods[uuid]:release()
  end
  petSpawner:markDirty()

  for uuid, recruit in pairs(recruitSpawner.followers) do
    if not recruit:dead() then
      recruit:spawn()
    end
  end
  recruitSpawner:markDirty()

  return true
end


function uninit()
  status.clearPersistentEffects("shipCrew")
  if onOwnShip() then
    status.addEphemeralEffects(recruitSpawner:getShipEphemeralEffects())
  end

  storage.pods = {}

  for uuid, pod in pairs(petSpawner.pods) do
    -- Player is leaving the world; return all pets
    pod:recall()
    storage.pods[uuid] = pod:store()
  end

  recruitSpawner:uninit()
  for category, companions in pairs(recruitSpawner:storeCrew()) do
    playerCompanions.setCompanions(category, companions)
  end
  storage.recruits = recruitSpawner:store()
end



function update(dt)
  local limit = status.stat("minionStatsBonus") + status.resource("minionSlotsCount")
  if petCount > limit then
     i = 1
     deactivatePod(petArray[i])
     while i < petCount do
        petArray[i] = petArray[i + 1]
        i = i + 1
     end
     petArray[i] = nil
  end
  -- end
  if limit < 1 then 
    status.setResource("minionSlotsCount", 1)
  end
  --if onOwnShip() then
    
   --end
  if not self.spawnedCompanions then
    self.spawnedCompanions = spawnCompanions()
  end

  promises:update()

  for uuid,_ in pairs(storage.activePods) do
    local pod = petSpawner.pods[uuid]
    pod:update(dt)
    local podItem = player.getItemWithParameter("podUuid", uuid)
    if pod:dead() or not podItem then
      deactivatePod(uuid)
    else
      petSpawner:setPodCollar(uuid, podItem.parameters.currentCollar)
    end
  end

  recruitSpawner:update(dt)
  if onOwnShip() then
    recruitSpawner:shipUpdate(dt)

    for uuid, recruit in pairs(recruitSpawner.shipCrew) do
      if not recruitSpawner.beenOnShip[uuid] then
        runFirstShipExperience(uuid, recruit)
      end
    end
  end

  if petSpawner:isDirty() then
    local activePets = {}
    for uuid,_ in pairs(storage.activePods) do
      for _,pet in pairs(petSpawner.pods[uuid].pets) do
        if pet:statusReady() and not pet:dead() then
          activePets[#activePets+1] = pet:toJson()
        end
      end
    end
    playerCompanions.setCompanions("pets", activePets)
    petSpawner:clearDirty()
  end

  if recruitSpawner:isDirty() then
    updateShipCrewEffects()
    updateShipUpgrades()

    logCrewSize()

    for category, companions in pairs(recruitSpawner:storeCrew()) do
      playerCompanions.setCompanions(category, companions)
    end
    recruitSpawner:clearDirty()
  end

  if onOwnShip() and recruitSpawner:crewSize() >= recruitSpawner.crewLimit() then
    grantNextLicense()
  end

  if storage.pendingItem then
    storage.pendingItemDelay = (storage.pendingItemDelay or 0) - dt
    if storage.pendingItemDelay <= 0 then
      player.giveItem(storage.pendingItem)
      storage.pendingItem = nil
      storage.pendingItemDelay = nil
    end
  end
end



-- Activate means 'regard this pod as active' but do not release yet.
-- When the player throws the filledcapturepod, activatePod is called.
-- When the filledcapturepod hits something, it calls spawnFromPod to release
-- the monster.
petArray = {}
function activatePod(podUuid)
  --local uplimit = config.getParameter("activePodLimit")
  local limit = status.stat("minionStatsBonus") + status.resource("minionSlotsCount")

  
  
  local pod = petSpawner.pods[podUuid]
  if not pod then
    sb.logInfo("Cannot activate invalid pod %s", podUuid)
    return
  end
  if petCount < limit then
    petCount = petCount + 1
    petArray[petCount] = podUuid
  end

     --deactivatePod(petArray[1])
     --i = 1
     --while i < petCount do
     --   petArray[i] = petArray[i + 1]
     --   i = i + 1
     --end
     --petArray[i] = nil
     --end
  -- If we have too many pets out, call some back
  --local overflow = math.max(util.tableSize(storage.activePods) + 1 - limit, 0)
  --for uuid,_ in pairs(storage.activePods) do
  --  deactivatePod(uuid)
  --  overflow = overflow - 1
  --  if overflow <= 0 then
  --    break
  --  end
  --end

  --storage.activePods[podUuid] = true
  --petSpawner:markDirty()
  storage.activePods[podUuid] = true
  petSpawner:markDirty()
end

-- Deactivate calls the pet back.
function deactivatePod(podUuid)
  local pod = petSpawner.pods[podUuid]
  if not pod then
    sb.logInfo("Cannot deactivate invalid pod %s", podUuid)
    return
  end

  pod:recall()
  storage.activePods[podUuid] = nil
  petSpawner:markDirty()
  petCount = petCount - 1
end
