require "/scripts/vec2.lua"

function init()
  self.returning = true
  self.returnOnHit = true
  self.pickupDistance = config.getParameter("pickupDistance")
  self.timeToLive = config.getParameter("timeToLive")
  self.speed = config.getParameter("speed")
  self.piercesAmount = config.getParameter("bounces")
  a = world.playerQuery(world.entityPosition(projectile.sourceEntity()), 81)
  self.ownerId = a[#(a)]
  alen = #(a)

  
  self.stickTime = config.getParameter("stickTime", 0)

  self.initialPosition = mcontroller.position()
 
  
end

function update(dt)
  
  a = world.playerQuery(mcontroller.position(), 81)
  self.ownerId = a[#(a)]
  alen = #(a) 
  local toTarget = world.distance(world.entityPosition(self.ownerId), mcontroller.position())
  mcontroller.setVelocity(vec2.mul(vec2.norm(toTarget), self.speed))
  --and world.entityExists(self.ownerId)
  if self.ownerId and world.entityDamageTeam(self.ownerId) == "enemy" and world.entityType(self.ownerId) ~= "player" then
    if not self.returning then
      if self.stickTimer then
        self.stickTimer = math.max(0, self.stickTimer - dt)
        if self.stickTimer == 0 then
          self.returning = true
        end
      elseif mcontroller.stickingDirection() then
        self.stickTimer = self.stickTime
      elseif mcontroller.isColliding() then
        self.returning = true
      else
        local distanceTraveled = world.magnitude(mcontroller.position(), self.initialPosition)
        if distanceTraveled > 0 then
          self.returning = true
        end
      end
    else
     a = world.playerQuery(mcontroller.position(), 81)
     self.ownerId = a[alen]
     
     local toTarget = world.distance(world.entityPosition(self.ownerId), mcontroller.position())
     
      mcontroller.setVelocity(vec2.mul(vec2.norm(toTarget), self.speed))
    end
  else
    alen = alen - 1
    a = world.playerQuery(mcontroller.position(), 81)
     self.ownerId = a[alen]
    local toTarget = world.distance(world.entityPosition(self.ownerId), mcontroller.position())
    mcontroller.setVelocity(vec2.mul(vec2.norm(toTarget), self.speed))
  end
  if world.entityType(a[#a]) == "player" then
    projectile.die()
   end
end

function hit(entityId)
  if self.returnOnHit then self.returning = true end
end

function projectileIds()
  return {entity.id()}
end
